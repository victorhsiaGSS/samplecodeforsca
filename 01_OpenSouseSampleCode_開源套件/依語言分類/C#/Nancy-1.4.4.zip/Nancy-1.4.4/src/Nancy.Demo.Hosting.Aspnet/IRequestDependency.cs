namespace Nancy.Demo.Hosting.Aspnet
{
    public interface IRequestDependency
    {
        string GetContent();
    }
}