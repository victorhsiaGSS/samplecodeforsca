namespace Nancy.Demo.Hosting.Aspnet
{
    public interface IApplicationDependency
    {
        string GetContent();
    }
}