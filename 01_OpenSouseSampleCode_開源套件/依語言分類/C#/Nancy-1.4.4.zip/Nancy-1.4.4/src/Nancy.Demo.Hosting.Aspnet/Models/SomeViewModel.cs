namespace Nancy.Demo.Hosting.Aspnet.Models
{
    public class SomeViewModel
    {
    }
}