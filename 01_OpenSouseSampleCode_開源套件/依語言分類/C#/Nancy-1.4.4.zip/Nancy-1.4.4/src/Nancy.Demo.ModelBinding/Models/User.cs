namespace Nancy.Demo.ModelBinding.Models
{
    public class User
    {
        public string Name { get; set; }

        public string Address { get; set; }
    }
}