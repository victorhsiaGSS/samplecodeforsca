namespace Nancy.Demo.ModelBinding
{
    using Nancy.Demo.ModelBinding.ModelBinders;
    using Nancy.ModelBinding;

    public class ModelBindingBootstrapper : DefaultNancyBootstrapper
    {
    }
}