namespace Nancy.Demo.Hosting.Owin.Models
{
    public class Index
    {
        public string StatusMessage { get; set; }
    }
}