﻿namespace Nancy.Tests.Fakes
{
    public struct StructModel
    {
    }
}
