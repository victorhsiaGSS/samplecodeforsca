namespace Nancy.Tests.Fakes
{
    public class ViewModel
    {
        
    }
}