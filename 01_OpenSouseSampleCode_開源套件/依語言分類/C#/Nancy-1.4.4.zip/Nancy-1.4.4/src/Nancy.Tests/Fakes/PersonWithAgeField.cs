﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Nancy.Tests.Fakes
{
    public class PersonWithAgeField : Person
    {
        public int Age;
    }
}
