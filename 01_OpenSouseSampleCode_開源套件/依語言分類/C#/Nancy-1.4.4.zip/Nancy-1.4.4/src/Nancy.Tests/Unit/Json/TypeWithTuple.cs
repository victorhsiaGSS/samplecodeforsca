namespace Nancy.Tests.Unit.Json
{
    using System;

    public class TypeWithTuple
    {
        public Tuple<int, int> Value { get; set; }
    }
}