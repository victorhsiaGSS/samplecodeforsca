﻿@Master['master']

@Tags
Date: 21/02/2012
Title: My First Blog Post
Tags: Blogging,Internet
@EndTags

@Section['Content']

@Partial['blogheader', Model.MetaData];

# First post!

Bacon ipsum dolor sit amet strip steak frankfurter bacon corned beef tenderloin chuck, prosciutto beef turkey tri-tip. Prosciutto spare ribs strip steak pork loin bresaola, pork chop sausage. Tri-tip salami ham hock pork pork belly fatback bresaola prosciutto turducken sirloin pork loin andouille sausage. Drumstick sausage tri-tip filet mignon doner corned beef kielbasa, chuck swine shank salami. Prosciutto pork chop biltong cow, leberkas ham hock ground round swine sausage ball tip tenderloin. Turducken pork chop ball tip, short loin frankfurter jowl pig. Prosciutto tail tri-tip, pancetta meatloaf doner ham flank venison pork loin filet mignon sausage.

@Partial['blogfooter', Model.MetaData];

@EndSection