﻿var api = {
    auth: "http://localhost:55581/restApi/auth",
    secure: "http://localhost:55581/restApi/secure"
};
