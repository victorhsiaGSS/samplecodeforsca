namespace Nancy.Demo.Bootstrapping.Aspnet
{
    public interface IApplicationDependency
    {
        string GetContent();
    }
}