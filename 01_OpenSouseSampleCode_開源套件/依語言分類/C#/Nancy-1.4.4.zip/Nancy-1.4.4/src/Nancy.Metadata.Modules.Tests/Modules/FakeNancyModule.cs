﻿namespace Nancy.Metadata.Modules.Tests.Modules
{
    public class FakeNancyModule : NancyModule
    {
    }
}