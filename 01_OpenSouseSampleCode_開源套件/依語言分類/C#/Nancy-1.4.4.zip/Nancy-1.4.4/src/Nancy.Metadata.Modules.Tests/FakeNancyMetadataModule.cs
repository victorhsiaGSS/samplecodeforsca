﻿namespace Nancy.Metadata.Modules.Tests
{
    using Nancy.Metadata.Modules;

    public class FakeNancyMetadataModule : MetadataModule<string>
    {
    }
}
