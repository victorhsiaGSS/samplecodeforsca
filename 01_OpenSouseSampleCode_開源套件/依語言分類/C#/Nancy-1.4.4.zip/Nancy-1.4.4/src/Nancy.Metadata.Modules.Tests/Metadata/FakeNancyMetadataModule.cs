﻿namespace Nancy.Metadata.Modules.Tests.Metadata
{
    using Nancy.Metadata.Modules;

    public class FakeNancyMetadataModule : MetadataModule<string>
    {
    }
}
