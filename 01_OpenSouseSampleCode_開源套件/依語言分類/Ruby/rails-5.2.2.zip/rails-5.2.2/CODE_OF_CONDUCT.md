# Contributor Code of Conduct

The Rails team is committed to fostering a welcoming community.

**Our Code of Conduct can be found here**:

http://rubyonrails.org/conduct/

For a history of updates, see the page history here:

https://github.com/rails/rails.github.com/commits/master/conduct/index.html

