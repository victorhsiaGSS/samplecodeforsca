# frozen_string_literal: true

module Fun
  module GamesHelper
    def stratego() "Iz guuut!" end
  end
end
