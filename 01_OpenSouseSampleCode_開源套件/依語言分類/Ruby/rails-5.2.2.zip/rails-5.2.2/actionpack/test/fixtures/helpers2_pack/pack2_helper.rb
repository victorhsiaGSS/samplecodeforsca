# frozen_string_literal: true

module Pack2Helper
  def conflicting_helper
    "pack2"
  end
end
