# frozen_string_literal: true

module Fun
  module PdfHelper
    def foobar() "baz" end
  end
end
