def option_1():
    """Documentation of 1st option.

    This docstring is intentionally long to fill the documentation panel box.

    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur vel
    auctor felis. Phasellus non risus maximus tortor molestie consectetur.
    Suspendisse in mauris eget nunc imperdiet elementum. Morbi consequat velit
    at elit suscipit, quis placerat est vulputate. Ut semper leo et fermentum
    gravida. Cras dui nisl, varius et lectus quis, maximus facilisis justo.
    """


def option_2():
    """Documentation of 2nd option."""
