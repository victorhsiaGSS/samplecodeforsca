JAVA_OPTS="-Xmx5000M"
export JAVA_OPTS
ANT_OPTS="-Xmx512m -Dscala.home=$SCALA_HOME"
export ANT_OPTS
