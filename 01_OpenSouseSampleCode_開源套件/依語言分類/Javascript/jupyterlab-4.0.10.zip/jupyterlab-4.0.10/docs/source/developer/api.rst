.. Copyright (c) Jupyter Development Team.
.. Distributed under the terms of the Modified BSD License.

JupyterLab API Reference
========================

.. this doc exists as a resolvable link target
.. which statically included files are not

.. meta::
    :http-equiv=refresh: 0;url=../api/index.html

The JupyterLab API reference docs are `here <../api/index.html>`_
if you are not redirected automatically.
