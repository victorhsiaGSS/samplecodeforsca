.. Copyright (c) Jupyter Development Team.
.. Distributed under the terms of the Modified BSD License.

.. _rtc:

Real Time Collaboration
=======================

From JupyterLab v4, it is possible to activate Real-Time Collaboration by installing
the extension `jupyter_collaboration <https://github.com/jupyterlab/jupyter_collaboration>`_.

For more information about Real-Time Collaboration in JupyterLab, please check out
``jupyter_collaboration`` documentation
`here <https://jupyterlab-realtime-collaboration.readthedocs.io>`_.
