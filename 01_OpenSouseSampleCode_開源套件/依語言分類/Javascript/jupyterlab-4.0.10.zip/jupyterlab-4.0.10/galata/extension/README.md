# @jupyterlab/galata-extension

This package is a JupyterLab extension easing access to some JupyterLab elements
for integration testing with `@jupyterlab/galata`.
