# Contributing to JupyterLab

If you're reading this section, you're probably interested in contributing to
JupyterLab. Welcome and thanks for your interest in contributing!

Please take a look at Contributing to Jupyterlab on
[Read the Docs](https://jupyterlab.readthedocs.io/en/stable/developer/contributing.html) or
[Repo docs](docs/source/developer/contributing.rst) (for the latest).
