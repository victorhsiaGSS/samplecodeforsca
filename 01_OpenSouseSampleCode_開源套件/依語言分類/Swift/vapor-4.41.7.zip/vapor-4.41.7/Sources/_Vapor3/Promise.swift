import Vapor

@available(*, deprecated, renamed: "EventLoopPromise")
public typealias Promise = EventLoopPromise
