@available(*, unavailable, message: "Use `app.http.server.configuration` instead.")
public typealias NIOServerConfig = Void
