@available(*, unavailable, message: "Use `Application` instead.")
public typealias Services = Void
