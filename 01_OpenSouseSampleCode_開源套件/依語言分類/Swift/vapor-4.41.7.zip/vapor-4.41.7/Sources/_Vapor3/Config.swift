@available(*, unavailable, message: "Use `Application` instead.")
public typealias Config = Void
