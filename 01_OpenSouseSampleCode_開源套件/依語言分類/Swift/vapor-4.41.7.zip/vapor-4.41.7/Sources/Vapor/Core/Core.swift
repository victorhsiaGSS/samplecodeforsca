extension Application {
    public var console: Console {
        get { self.core.storage.console }
        set { self.core.storage.console = newValue }
    }

    public var commands: Commands {
        get { self.core.storage.commands }
        set { self.core.storage.commands = newValue }
    }

    public var threadPool: NIOThreadPool {
        self.core.storage.threadPool
    }
    public var fileio: NonBlockingFileIO {
        .init(threadPool: self.threadPool)
    }

    public var allocator: ByteBufferAllocator {
        self.core.storage.allocator
    }

    public var running: Running? {
        get { self.core.storage.running.current }
        set { self.core.storage.running.current = newValue }
    }

    public var directory: DirectoryConfiguration {
        get { self.core.storage.directory }
        set { self.core.storage.directory = newValue }
    }

    internal var core: Core {
        .init(application: self)
    }

    public struct Core {
        final class Storage {
            var console: Console
            var commands: Commands
            var threadPool: NIOThreadPool
            var allocator: ByteBufferAllocator
            var running: Application.Running.Storage
            var directory: DirectoryConfiguration

            init() {
                self.console = Terminal()
                self.commands = Commands()
                self.commands.use(BootCommand(), as: "boot")
                self.threadPool = NIOThreadPool(numberOfThreads: 1)
                self.threadPool.start()
                self.allocator = .init()
                self.running = .init()
                self.directory = .detect()
            }
        }

        struct LifecycleHandler: Vapor.LifecycleHandler {
            func shutdown(_ application: Application) {
                try! application.threadPool.syncShutdownGracefully()
            }
        }

        struct Key: StorageKey {
            typealias Value = Storage
        }

        let application: Application

        var storage: Storage {
            guard let storage = self.application.storage[Key.self] else {
                fatalError("Core not configured. Configure with app.core.initialize()")
            }
            return storage
        }

        func initialize() {
            self.application.storage[Key.self] = .init()
            self.application.lifecycle.use(LifecycleHandler())
        }
    }
}
