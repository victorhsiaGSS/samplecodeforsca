extension DataProtocol {
    func copyBytes() -> [UInt8] {
        Array(self)
    }
}
