package sample;

/**
 * Testing this
 * @author Rob Winch
 *
 */
public class Sample {

	/**
	 * This does stuff
	 */
	public void doSample() {}
}
