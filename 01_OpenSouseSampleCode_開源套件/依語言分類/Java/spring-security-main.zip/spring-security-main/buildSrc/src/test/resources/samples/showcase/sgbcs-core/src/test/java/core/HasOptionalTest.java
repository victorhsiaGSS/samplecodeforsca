package core;

import org.junit.jupiter.api.Test;

public class HasOptionalTest {

	@Test
	public void test() {
		HasOptional.doStuffWithOptionalDependency();
	}

}
