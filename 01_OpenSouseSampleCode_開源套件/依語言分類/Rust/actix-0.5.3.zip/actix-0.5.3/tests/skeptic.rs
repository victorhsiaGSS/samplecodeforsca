#[cfg(unix)]
include!(concat!(env!("OUT_DIR"), "/skeptic-tests.rs"));
