README.txt - plugin

This is an "empty" Struts 2 plugin that you can use as the basis for a new
plugin.

For more on Struts plugins, see 

* http://struts.apache.org/2.x/docs/plugins.html

----------------------------------------------------------------------------
