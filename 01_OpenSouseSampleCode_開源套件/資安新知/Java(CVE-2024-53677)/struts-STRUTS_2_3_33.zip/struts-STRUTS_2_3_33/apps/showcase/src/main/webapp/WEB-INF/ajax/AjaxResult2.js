alert('This JavaScript currently being evaluated is the result...');
alert('... of an action executed on the server!');
